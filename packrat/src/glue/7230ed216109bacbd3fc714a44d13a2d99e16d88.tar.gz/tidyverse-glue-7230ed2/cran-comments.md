This is a re-submission. I have fixed the NOTES about https URLs.

## Test environments
* local OS X install, R 3.3.2
* ubuntu 12.04 (on travis-ci), R-release, R-devel
* Rhub

## R CMD check results

0 errors | 0 warnings | 0 note

## Downstream dependencies
I ran `R CMD check` on all 19 reverse dependencies (https://github.com/tidyverse/glue/tree/master/revdep).

There were no issues found.
